# 开发记录索引（未全部入包）

本目录只收工程脚本、测试与依赖锁定，作为开发记录，不是科学成果。
以下开发/审计资料保留在仓库中，未复制进本包，以免与正式材料混淆：

| 路径 | 类型 | 处理 |
|---|---|---|
| `README.md` | 项目总览（混有 A/B 关键数字） | 未入包；引用 B 时只用 `FORMAL/BASELINE_B/` |
| `RELEASE_CHECKLIST.md` | Phase 9 发布检查（含基线 A 与待办） | 未入包，仅作开发记录 |
| `docs/ENGINEERING_ACCEPTANCE.md` | 工程验收记录 | 未入包 |
| `docs/PHASE10_REPORT.md` | Phase 10 工程说明 | 未入包 |
| `docs/audit_evidence/` | 审计脚本与证据 | 未入包 |
| `paper/`、`statement/`、`figures/` | 论文/赛题/图件 | 未入包 |
| `models/`、`date/` | 模型产物与官方数据（gitignored） | 未入包，哈希/来源见 `VERSION.json` |
