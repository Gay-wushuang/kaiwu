# 基线 A 历史对照（不收入正式包）

本包**只使用基线 B**。以下基线 A（队友原始预测 + 三次真机报告）仅作为历史对照，
不复制进本包，不得与 B 的模型、预测、指标或真机结果混用。

| 类别 | 位置 | 说明 |
|---|---|---|
| 原始预测池 | `code/predictions/*.csv` | 基线 A 模型输出；与 B 同名文件最大绝对差 = 4.733 |
| 三次真机报告 | `results/vendor_reports/*.pdf` | 2026-11-26 的 3 个任务（任务 3 为 SPQC-1000） |
| 真机统计/逐样本 | `results/cim_stats/`、`results/cim_samples/` | 仅对应上述基线 A 三次任务 |
| 真机索引 | `results/EXPERIMENT_INDEX.md` | 基线 A 三次任务索引，含 MISSING 标记 |
| 历史日志 | `results/logs/` | 基线 A 提交/下载日志 |

基线 B 的预测在 `FORMAL/BASELINE_B/predictions/`，真机在 `FORMAL/ROUND1/`。

禁止事项：
1. 不得用 `code/predictions/` 的 V̂ 解释基线 B 的最优解；
2. 不得把基线 A 的 3 个任务写成第一轮 5 个任务；
3. 不得把基线 A 的硬件时长/设备型号用于 B。
